#!usr/bin/env python3
#-*- coding utf-8 -*-

# fichier : mini_projet_avion.py
# auteur  : Jules Herbin
# date    : 19/09/2022


from turtle import *
from random import *


class Simulation:
    def __init__(self, balise, vols, plans):
        self.balise = balise
        self.vols = vols
        self.plans = plans
        self.bal = Turtle()
        self.bal.ht()



    def get_balise(self):
        return self.balise

    def get_vols(self):
        return self.vols

    def get_plans(self):
        return self.plans



    def demarrer(self):
        self.bal.up()
        self.bal.speed(0)
        for cle in self.balise.keys():
            self.bal.setposition(self.balise[cle])
            self.bal.dot(10, "blue")
            self.bal.write(cle)

        for c in self.vols.keys():
            av = Avion(self.vols[c])
            av.decoller()
            av.voler(self.plans[self.vols[c]], self.balise)
            av.atterrir()







class Avion:

    def __init__(self,code):
        self.code = code
        self.position = (0,0)
        self.direction = 0
        self.vitesse = 0
        self.avion = Turtle(visible=False)



    def get_code(self):
        return self.code

    def get_position(self):
        return self.position

    def get_direction(self):
        return self.direction

    def get_vitesse(self):
        return self.vitesse

    def get_avion(self):
        return self.avion



    def decoller(self):
        self.vitesse = 1
        self.avion.speed(self.vitesse)
        couleur = ["yellow", "gold", "orange", "red", "maroon", "violet", "pink", "magenta", "purple", "navy", "blue", "sky blue", "cyan", "turquoise", "lightgreen", "green", "darkgreen", "chocolate", "brown", "black", "gray"]
        i = randint(0, len(couleur)-1)
        self.avion.color(couleur[i])

    def voler(self, plan_vol, dico_balise):
        self.avion.up()
        self.avion.setposition(dico_balise[plan_vol[0]])
        self.avion.pd()
        self.avion.st()
        for i in plan_vol:
            angle = self.avion.towards(dico_balise[i])
            self.avion.setheading(angle)
            self.avion.goto(dico_balise[i])
            
    def atterrir(self):
        self.vitesse = 0
        self.avion.speed(self.vitesse)







if __name__=="__main__":
    vols = {
        'AF2267': ('Bordeaux', 'Paris'),
        'YZ1432': ('Nantes', 'Nice'),
        'IT2256': ('Lille', 'Montpellier'),
        'BA5983': ('Brest', 'Grenoble'),
        'IB4521': ('Bayonne', 'Strasbourg'),
        'DT7856': ('Rennes', 'Marseille')
        }

    
    plans = {
        ('Bordeaux', 'Paris'): ['BDX', 'LMG', 'CDG'],
        ('Nantes', 'Nice'): ['NAT', 'LMG', 'MRS', 'NCE'],
        ('Lille', 'Montpellier'): ['LIL', 'CDG', 'LMG', 'TLS', 'MPL'],
        ('Brest', 'Grenoble'): ['BST', 'NAT', 'LMG', 'LYN', 'GRN'],
        ('Bayonne', 'Strasbourg'): ['BYN', 'TLS', 'LYN', 'STG'],
        ('Rennes', 'Marseille'): ['REN', 'LMG', 'MPL', 'MRS']
        }

    
    balises = {
        'CDG': (0, 170),
        'BDX': (-140, -100),
        'BYN': (-180, -180),
        'TLS': (-40, -175),
        'NAT': (-180, 60),
        'BST': (-310, 140),
        'REN': (-260, 120),
        'LIL': (40, 300),
        'STG': (240, 150),
        'LMG': (-55, -35),
        'LYN': (130, -40),
        'MRS': (130, -180),
        'GRN': (160, -80),
        'NCE': (230, -170),
        'MPL': (70, -175)
        }

    
    fr = Simulation(balises, vols, plans)
    fr.demarrer()


# fin du fichier mini_projet_avion.py
